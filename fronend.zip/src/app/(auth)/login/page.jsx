'use client'

import { useEffect, useMemo, useState } from 'react'
import { useDispatch } from 'react-redux'
import { useForm } from 'react-hook-form'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'

import {
  login,
  forgotPassword,
  resetPassword,
} from '@/store/auth/auth-operations'

import Input from '@/components/shared/input/Input'
import Button from '@/components/shared/button/Button'
import Text from '@/components/shared/text/Text'
import AuthCard from '@/components/auth/AuthCard'
import AuthModal from '@/components/auth/AuthModal'

import { useTranslate } from '@/utils/translate/translate'

function validateEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim())
}

export default function LoginPage() {
  const dispatch = useDispatch()
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const API_URL = process.env.NEXT_PUBLIC_API_URL

  const resetToken = searchParams.get('resetToken') || ''
  const [isResetModalOpen, setIsResetModalOpen] = useState(false)
  const [resetSubmitting, setResetSubmitting] = useState(false)

  const tLinkAction = useTranslate('Sign up')

  const {
    register,
    handleSubmit,
    getValues,
    setError,
    clearErrors,
    formState: { errors, isSubmitting },
    reset,
  } = useForm({
    mode: 'onSubmit',
    reValidateMode: 'onChange',
    defaultValues: {
      email: '',
      password: '',
    },
  })

  const {
    register: registerReset,
    handleSubmit: handleResetSubmit,
    getValues: getResetValues,
    reset: resetResetForm,
    formState: { errors: resetErrors },
  } = useForm({
    mode: 'onSubmit',
    reValidateMode: 'onChange',
    defaultValues: {
      password: '',
      confirmPassword: '',
    },
  })

  useEffect(() => {
    setIsResetModalOpen(Boolean(resetToken))
  }, [resetToken])

  const cleanedLoginUrl = useMemo(() => pathname || '/login', [pathname])

  const closeResetModal = () => {
    if (resetSubmitting) return

    setIsResetModalOpen(false)
    resetResetForm()
    router.replace(cleanedLoginUrl)
  }

  const onResetPasswordSubmit = async (data) => {
    if (!resetToken) return

    setResetSubmitting(true)

    try {
      await dispatch(
        resetPassword({
          token: resetToken,
          password: data.password,
          confirmPassword: data.confirmPassword,
        }),
      ).unwrap()

      setIsResetModalOpen(false)
      resetResetForm()
      router.replace(cleanedLoginUrl)
    } catch {
      // handled by ToastListener
    } finally {
      setResetSubmitting(false)
    }
  }

  const onSubmit = async (data) => {
    try {
      await dispatch(
        login({
          email: data.email.trim(),
          password: data.password,
        }),
      ).unwrap()

      reset()
      router.push('/')
    } catch {
      // handled by ToastListener
    }
  }

  const onForgotPassword = async () => {
    const email = String(getValues('email') || '').trim()

    if (!email) {
      setError('email', {
        type: 'manual',
        message: 'Email is required',
      })
      return
    }

    if (!validateEmail(email)) {
      setError('email', {
        type: 'manual',
        message: 'Enter a valid email',
      })
      return
    }

    clearErrors('email')

    try {
      await dispatch(forgotPassword({ email })).unwrap()
    } catch {
      // handled by ToastListener
    }
  }

  const onGoogleClick = (e) => {
    e.preventDefault()
    if (!API_URL) return

    const currentOrigin = encodeURIComponent(window.location.origin)
    window.location.href = `${API_URL}/api/google?origin=${currentOrigin}`
  }

  const form = (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="grid gap-4">
      <Input
        id="login-email"
        label="Email"
        type="email"
        autoComplete="email"
        inputMode="email"
        placeholder="you@example.com"
        hint="Enter the email you used during registration."
        required
        caseMode="sentence"
        {...register('email', {
          required: 'Email is required',
          validate: (value) => validateEmail(value) || 'Enter a valid email',
        })}
        error={errors.email?.message}
        inputClassName="h-12"
      />

      <Input
        id="login-password"
        label="Password"
        type="password"
        autoComplete="current-password"
        placeholder="Enter your password"
        hint="At least 6 characters."
        required
        caseMode="sentence"
        {...register('password', {
          required: 'Password is required',
          minLength: {
            value: 6,
            message: 'Password must be at least 6 characters',
          },
        })}
        error={errors.password?.message}
        inputClassName="h-12"
      />

      <div className="-mt-1 flex justify-end">
        <button
          type="button"
          onClick={onForgotPassword}
          className="inline-flex"
        >
          <Text
            as="span"
            variant="caption"
            color="faint"
            className="text-right transition-opacity hover:opacity-80"
            caseMode="sentence"
          >
            Forgot password?
          </Text>
        </button>
      </div>

      <Button
        type="submit"
        fullWidth
        loading={isSubmitting}
        disabled={isSubmitting}
        className="mt-1 min-h-12 rounded-2xl"
      >
        Sign in
      </Button>
    </form>
  )

  return (
    <>
      <AuthCard
        title="Welcome back"
        subtitle="Sign in to your account to continue creating and managing AI image styles."
        form={form}
        footerText="Don’t have an account?"
        footerLinkHref="/register"
        footerLinkText={tLinkAction}
        googleEnabled={Boolean(API_URL)}
        onGoogleClick={onGoogleClick}
        googleText="Continue with Google"
        orText="or"
      />

      <AuthModal
        open={isResetModalOpen}
        title="Reset password"
        description="Create a new password for your account. After saving it, you can sign in with the new password."
      >
        <form
          onSubmit={handleResetSubmit(onResetPasswordSubmit)}
          noValidate
          className="grid gap-4"
        >
          <Input
            id="reset-password"
            label="New password"
            type="password"
            autoComplete="new-password"
            placeholder="Create new password"
            hint="At least 6 characters."
            required
            caseMode="sentence"
            {...registerReset('password', {
              required: 'Password is required',
              minLength: {
                value: 6,
                message: 'Password must be at least 6 characters',
              },
              maxLength: {
                value: 64,
                message: 'Password must be at most 64 characters',
              },
            })}
            error={resetErrors.password?.message}
            inputClassName="h-12"
          />

          <Input
            id="reset-confirm-password"
            label="Confirm password"
            type="password"
            autoComplete="new-password"
            placeholder="Repeat new password"
            hint="Repeat the same password."
            required
            caseMode="sentence"
            {...registerReset('confirmPassword', {
              required: 'Please confirm your password',
              validate: (value) =>
                value === getResetValues('password') ||
                'Passwords do not match',
            })}
            error={resetErrors.confirmPassword?.message}
            inputClassName="h-12"
          />

          <div className="mt-2 grid gap-3 sm:grid-cols-2">
            <Button
              type="button"
              variant="secondary"
              fullWidth
              disabled={resetSubmitting}
              onClick={closeResetModal}
              className="min-h-12 rounded-2xl"
            >
              Cancel
            </Button>

            <Button
              type="submit"
              fullWidth
              loading={resetSubmitting}
              disabled={resetSubmitting}
              className="min-h-12 rounded-2xl"
            >
              Save password
            </Button>
          </div>
        </form>
      </AuthModal>
    </>
  )
}
